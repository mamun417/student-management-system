<div class="row border-bottom">
    <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
        </div>
        <ul class="nav navbar-top-links navbar-right">
            <li>
                <a href="" onclick="event.preventDefault(); document.getElementById('logout_form').submit()">
                    <i class="fa fa-sign-out"></i> Log out
                </a>

                <form id="logout_form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                </form>
            </li>

        </ul>

    </nav>
</div>


<?php /**PATH D:\Xampp-7.3\htdocs\student-management-system\resources\views/elements/header.blade.php ENDPATH**/ ?>