<div class="footer">
    <div class="pull-right">
        10GB of <strong>250GB</strong> Free.
    </div>
    <div>
        <strong>Copyright</strong> Example Company &copy; 2014-2017
    </div>
</div>
<?php /**PATH D:\Xampp-7.3\htdocs\student-management-system\resources\views/elements/footer.blade.php ENDPATH**/ ?>