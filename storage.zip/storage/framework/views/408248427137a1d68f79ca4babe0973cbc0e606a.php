<?php echo e($slot); ?>

<?php /**PATH D:\Xampp-7.3\htdocs\student-management-system\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>