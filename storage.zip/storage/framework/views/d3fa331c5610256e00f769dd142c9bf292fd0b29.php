
<?php echo $__env->make('partials.flash_messages.flashMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="form-group">
    <label class="col-lg-2 control-label">Name<span class="required-star"> *</span></label>
    <div class="col-lg-10">
        <input value="<?php echo e(isset($role->name) ? $role->name:''); ?>" required="required" name="name" type="text" class="form-control">
    </div>
</div>

<div class="form-group">
    <label class="col-lg-2 control-label">Permission<span class="required-star"> *</span></label>
    <div class="col-lg-10">
        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            

            <div class="checkbox m-r-xs">
                <input <?php echo e(isset($rolePermissions)?((Arr::has($rolePermissions, $permission->id))?'checked':''):''); ?> name="permission[]" value="<?php echo e($permission->id); ?>" type="checkbox" id="<?php echo e($permission->id); ?>">
                <label for="<?php echo e($permission->id); ?>">
                    <?php echo e($permission->name); ?>

                </label>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH D:\Xampp-7.3\htdocs\student-management-system\resources\views/adminstration/role/element.blade.php ENDPATH**/ ?>